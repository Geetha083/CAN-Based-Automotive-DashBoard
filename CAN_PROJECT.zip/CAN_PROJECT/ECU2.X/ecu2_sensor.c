
#include "ecu2_sensor.h"
#include "adc.h"
#include "digital_keypad.h"

uint16_t get_rpm(void)
{
    uint16_t ADC_Val = read_adc(0x04);

    uint16_t RPM = ((unsigned long)ADC_Val * 6000) / 1023;

    if(RPM > 6000)
    {
        RPM = 6000;
    }

    return RPM;
}

IndicatorStatus process_indicator()
{
    unsigned char val = read_digital_keypad(STATE_CHANGE);

    if(val == 0x0E)
    {
        OFF = 0;

        if(right == 1)
        {
            right = 0;
            RB6 = 0;
            RB7 = 0;
        }

        left = 1;
        return e_ind_left;
    }
    else if(val == 0x0B)
    {
        OFF = 0;

        if(left == 1)
        {
            left = 0;
            RB0 = 0;
            RB1 = 0;
        }

        right = 1;
        return e_ind_right;
    }
    else if(val == 0x0D)
    {
        OFF = 1;
        left = 0;
        right = 0;

        return e_ind_off;
    }

    if(left == 1)
    {
        return e_ind_left;
    }

    if(right == 1)
    {
        return e_ind_right;
    }

    return e_ind_off;
}
