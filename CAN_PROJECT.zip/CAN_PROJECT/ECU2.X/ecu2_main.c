
#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include "digital_keypad.h"

char OFF = 1;
char left = 0;
char right = 0;

unsigned int delayL = 0;
unsigned int delayR = 0;

void Blink_Led(IndicatorStatus input) {
    switch (input) {
        case e_ind_left:

            RB6 = 0;
            RB7 = 0;
            delayR = 0;

            if (delayL++ == 2) {
                RB0 = !RB0;
                RB1 = !RB1;
                delayL = 0;
            }
            break;

        case e_ind_right:

            RB0 = 0;
            RB1 = 0;
            delayL = 0;

            if (delayR++ == 2) {
                RB6 = !RB6;
                RB7 = !RB7;
                delayR = 0;
            }
            break;

        case e_ind_off:

            RB0 = 0;
            RB1 = 0;
            RB6 = 0;
            RB7 = 0;

            delayL = 0;
            delayR = 0;
            break;
    }
}

int main() {
    TRISB0 = 0;
    TRISB1 = 0;
    TRISB6 = 0;
    TRISB7 = 0;

    init_adc();
    init_digital_keypad();
    init_can();

    while (1) {
        uint16_t RPM = get_rpm();

        uint8_t rpm_data[2];

        rpm_data[0] = RPM & 0xFF;
        rpm_data[1] = (RPM >> 8) & 0xFF;

        can_transmit(RPM_MSG_ID, rpm_data, 2);

        IndicatorStatus val = process_indicator();

        uint8_t tx_data = (uint8_t) val;

        can_transmit(INDICATOR_MSG_ID, &tx_data, 1);

        Blink_Led(val);
    }
}
