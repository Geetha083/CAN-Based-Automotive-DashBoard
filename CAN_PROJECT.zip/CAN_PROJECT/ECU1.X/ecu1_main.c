#include <xc.h>
#include <stdint.h>

#include "adc.h"
#include "can.h"
#include "ecu1_sensor.h"
#include "msg_id.h"
#include "digital_keypad.h"

void main(void)
{
    uint16_t speed;
    unsigned char gear;

    uint8_t speed_data[1];
    uint8_t gear_data[1];

    init_adc();
    init_can();
    init_digital_keypad();

    while (1)
    {
        /* Read speed from potentiometer */
        speed = get_speed();

        /* Send speed through CAN */
      speed_data[0] = (uint8_t)speed;

       can_transmit(SPEED_MSG_ID, speed_data, 1);

        /* Existing gear functionality - unchanged */
        gear = get_gear_pos();

        gear_data[0] = (uint8_t)gear;

        can_transmit(GEAR_MSG_ID, gear_data, 1);
    }
}