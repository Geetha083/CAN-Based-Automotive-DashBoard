#include <xc.h>
#include <stdint.h>

#include "ecu1_sensor.h"
#include "adc.h"
#include "digital_keypad.h"

/* Read speed using ADC channel 4 */

uint16_t get_speed(void)
{
    unsigned short adc_value;

    adc_value = read_adc(SPEED_ADC_CHANNEL);
    return (uint16_t)(((unsigned long)adc_value * 100U) / 1023U);
}
/* Read and update gear position */
unsigned char get_gear_pos(void)
{
    static unsigned char gear = 'N';

    unsigned char key;

    key = read_digital_keypad(STATE_CHANGE);

    if (key == SWITCH1)
    {
        /* Increase gear */
        if (gear == 'N' || gear == 'R')
        {
            gear = '1';
        }
        else if (gear >= '1' && gear < '5')
        {
            gear++;
        }
    }
    else if (key == SWITCH2)
    {
        /* Decrease gear */
        if (gear > '1' && gear <= '5')
        {
            gear--;
        }
        else if (gear == '1')
        {
            gear = 'N';
        }
    }
    else if (key == SWITCH3)
    {
        gear = 'R';
    }
    else if (key == SWITCH4)
    {
        gear = 'N';
    }

    return gear;
}

