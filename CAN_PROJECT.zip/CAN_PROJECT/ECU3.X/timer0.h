/* 
 * File:   timer0.h
 * Author: geeth
 *
 * Created on 29 October, 2026, 8:52 PM
 */
#ifndef TIMER0_H
#define TIMER0_H

void init_timer0(void);

#endif