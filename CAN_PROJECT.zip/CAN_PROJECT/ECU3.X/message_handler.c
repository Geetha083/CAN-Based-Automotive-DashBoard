#include <xc.h>
#include <stdint.h>
#include "can.h"
#include "clcd.h"
#include "msg_id.h"
#include "message_handler.h"

static uint16_t speed = 0;
static unsigned char gear = '0';
static uint16_t rpm = 0;

volatile unsigned char led_state = 0;
volatile unsigned char status = 0;

static void display_dashboard(void)
{
    unsigned char line2[17];

    /* First line - Labels */
    clcd_print("SPD|GR|RPM|IND", LINE1(0));

    /* Speed - 3 digits */
    line2[0] = (speed / 100) + '0';
    line2[1] = ((speed / 10) % 10) + '0';
    line2[2] = (speed % 10) + '0';

    line2[3] = '|';

    /* Gear */
    line2[4] = gear;

    line2[5] = '|';

    /* RPM - 4 digits */
    line2[6] = (rpm / 1000) + '0';
    line2[7] = ((rpm / 100) % 10) + '0';
    line2[8] = ((rpm / 10) % 10) + '0';
    line2[9] = (rpm % 10) + '0';

    line2[10] = '|';

    /* Indicator */
    if (status == e_ind_left)
    {
        line2[11] = '<';
        line2[12] = '-';
        line2[13] = ' ';
    }
    else if (status == e_ind_right)
    {
        line2[11] = '-';
        line2[12] = '>';
        line2[13] = ' ';
    }
    else if (status == e_ind_parking)
    {
        line2[11] = '<';
        line2[12] = '>';
        line2[13] = ' ';
    }
    else
    {
        line2[11] = 'O';
        line2[12] = 'F';
        line2[13] = 'F';
    }

    line2[14] = ' ';
    line2[15] = '\0';

    clcd_print(line2, LINE2(0));
}

void handle_speed_data(uint8_t *data, uint8_t len)
{
    if (len >= 1)
    {
        speed = data[0];
    }
}
void handle_gear_data(uint8_t *data, uint8_t len)
{
    if (len >= 1)
    {
        gear = data[0];
    }
}

void handle_rpm_data(uint8_t *data, uint8_t len)
{
    if (len >= 2)
    {
        rpm = (uint16_t)data[0] | ((uint16_t)data[1] << 8);

        if (rpm > 6000)
        {
            rpm = 6000;
        }
    }
}
void handle_indicator_data(uint8_t *data, uint8_t len)
{
    if (len >= 1)
    {
        status = data[0];

        if (status == 1)       // LEFT
        {
            LEFT_IND_ON();
            RIGHT_IND_OFF();
        }
        else if (status == 2)  // RIGHT
        {
            RIGHT_IND_ON();
            LEFT_IND_OFF();
        }
        else if (status == 3)  // PARKING
        {
            LEFT_IND_ON();
            RIGHT_IND_ON();
        }
        else                   // OFF
        {
            LEFT_IND_OFF();
            RIGHT_IND_OFF();
        }
    }
}
void process_canbus_data(void)
{
    uint16_t msg_id;
    uint8_t data[8];
    uint8_t len = 0;

    can_receive(&msg_id, data, &len);

    if (len > 0)
    {
        switch (msg_id)
        {
            case SPEED_MSG_ID:
                handle_speed_data(data, len);
                break;

            case GEAR_MSG_ID:
                handle_gear_data(data, len);
                break;

            case RPM_MSG_ID:
                handle_rpm_data(data, len);
                break;

            case INDICATOR_MSG_ID:
                handle_indicator_data(data, len);
                break;
        }

        display_dashboard();
    }
}